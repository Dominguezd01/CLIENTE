let num = parseInt(prompt("Introduce un número"));

for (let i = 0; i<=10;i++){
    console.log(`${num} X ${i} = ${num*i}`)
}

